To change your skin please follow the link:
http://dhtmlx.com/docs/products/skinBuilder/index.shtml#d9cd0fa633