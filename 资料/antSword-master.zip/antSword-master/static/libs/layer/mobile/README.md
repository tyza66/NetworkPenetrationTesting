﻿
## layer mobile
layer mobile是为移动设备（手机、平板等webkit内核浏览器/webview）量身定做的弹层支撑，采用Native JavaScript编写，完全独立于PC版的layer，您需要按照场景选择使用。

[文档与演示](http://sentsin.com/layui/layer/)   

1. 无需依赖任何库，只加载layer.m.js即可
2. 小巧玲珑，性能卓越、柔情似水…
3. 具备无以伦比的自适应功能
4. 灵活的皮肤自定义支撑，充分确保弹层风格多样化
5. 丰富、科学的接口，让弹弹弹层无所不能

## 备注
[官网](http://sentsin.com/layui/layer/)、[有问必答](http://say.sentsin.com/home-48.html)
