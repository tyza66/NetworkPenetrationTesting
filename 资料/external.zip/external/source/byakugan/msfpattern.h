#include <string.h>

void msf_pattern_create(int, char *);
int msf_pattern_offset(int, unsigned int);
