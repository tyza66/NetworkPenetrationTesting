BOOL	maskHardwareBreaks(void);

void mushishiDetect(void);
void mushishiDefeat(void);
