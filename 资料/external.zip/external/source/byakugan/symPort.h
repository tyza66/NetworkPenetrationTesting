#define	MAP_BUF_SIZE			512
#define	MAP_STATE_ENTRYPOINT	1
#define	MAP_STATE_LOCALSYM		2

HRESULT		addMapFile(char *imageName, char *mapPath);
